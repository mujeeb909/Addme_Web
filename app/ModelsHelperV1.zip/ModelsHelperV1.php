<?php
// models
use App\Models\CustomerProfile;
use App\Models\CustomerProfileTemplate;
use App\Models\Profile;
use App\Models\User;
use App\Models\UserSettings;
use App\Models\UserTemplate;

function UserObj($User, $UserID = 0)
{
    $User->banner = image_url($User->banner);
    $User->logo = image_url($User->logo);
    $User->profile_image = ($User->logo);

    unset($User->vcode, $User->vcode_expiry, $User->access_token, $User->custom_gender);
    return $User;
}

function ProfileButton($CustomerProfileId, $CustomerProfile = null, $ProfileType = null, $platform = 'bp')
{
    if ($platform == 'bp') {
        if ($CustomerProfileId != 0) {
            $CustomerProfile = CustomerProfile::where('id', $CustomerProfileId);
            if ($CustomerProfile->count()) {
                $Obj = $CustomerProfile->first();
            } else {
                return [];
            }
        } else if ($CustomerProfile != null) {
            $Obj = $CustomerProfile;
        }

        $Profile = $ProfileType->first();

        $Obj->value = $Obj->profile_link;
        $Obj->href = $Obj->profile_link != '' ? (($Obj->profile_code != 'file') ? $Profile->base_url . $Obj->profile_link : $Obj->file_image) : '';
        $Obj->icon_url =  $Obj->icon != '' ? icon_url() . $Obj->icon : icon_url() . $Profile->icon;
        $Obj->template_id = (int) $Obj->user_template_id;
        $Obj->visible = true_false($Obj->status);
        $Obj->is_highlighted = true_false($Obj->is_focused);
        $Obj->is_unique = (int) $Obj->is_unique;
        $Obj->type = $Profile->type;

        unset($Obj->icon, $Obj->status, $Obj->is_focused, $Obj->file_image, $Obj->user_id, $Obj->is_business, $Obj->is_direct,  $Obj->is_default, $Obj->global_id, $Obj->created_by, $Obj->created_at, $Obj->updated_by, $Obj->updated_at, $Obj->profile_link, $Obj->user_template_id);

        return $Obj;
    } else {

        if ($CustomerProfileId != 0) {
            $CustomerProfile = CustomerProfile::where('id', $CustomerProfileId);
            if ($CustomerProfile->count()) {
                $Obj = $CustomerProfile->first();
            } else {
                return [];
            }
        } else if ($CustomerProfile != null) {
            $Obj = $CustomerProfile;
        }

        if ($Obj->profile_code == 'contact-card') {
            $Obj->profile_link = main_url() . '/contact-card/' . encrypt($Obj->user_id);
        } else if ($Obj->profile_code == 'file') {
            $Obj->profile_link = file_url() . $Obj->file_image;
        }

        $Obj->icon = ($Obj->icon != '' && $Obj->icon != NULL) ? icon_url() . $Obj->icon : $Obj->icon;
        $Obj->file_image = ($Obj->file_image != '' && $Obj->file_image != NULL) ? file_url() . $Obj->file_image : $Obj->file_image;

        $query = \DB::table('template_assignees AS ta')->select('cpt.user_template_id', 'cpt.is_unique');
        $query->leftJoin('customer_profile_templates AS cpt', 'cpt.id', '=', 'ta.customer_profile_template_id');
        $query->where('ta.customer_profile_id', $Obj->id);
        if ($query->count() > 0) {
            $rec = $query->first();
            $Obj->template_id = (int) $rec->user_template_id;
            $Obj->is_unique = (int) $rec->is_unique;
        } else {
            $Obj->template_id = 0;
            $Obj->is_unique = 0;
        }

        return $Obj;
    }
}

function TemplateProfileButton($TemplateProfileId, $TemplateProfile = null)
{
    if ($TemplateProfileId != 0) {
        $TemplateProfile = CustomerProfileTemplate::where('id', $TemplateProfileId)->first();
    }

    $Profile = Profile::where('profile_code', $TemplateProfile->profile_code)->first();

    $TemplateProfile->value = $TemplateProfile->profile_link == NULL ? '' : $TemplateProfile->profile_link;
    if ($TemplateProfile->profile_link == NULL || $TemplateProfile->profile_link == '') {
        $TemplateProfile->href = '';
    } else {
        $TemplateProfile->href = ($TemplateProfile->profile_code != 'file') ? $Profile->base_url . $TemplateProfile->profile_link : $TemplateProfile->file_image;
    }

    $TemplateProfile->icon_url = $TemplateProfile->icon != '' ? icon_url() . $TemplateProfile->icon : icon_url() . $Profile->icon;
    $TemplateProfile->visible = true_false($TemplateProfile->status);
    $TemplateProfile->is_highlighted = true_false($TemplateProfile->is_focused);

    unset($TemplateProfile->icon, $TemplateProfile->status, $TemplateProfile->is_focused, $TemplateProfile->file_image, $TemplateProfile->user_id, $TemplateProfile->is_business, $TemplateProfile->is_direct, $TemplateProfile->sequence, $TemplateProfile->is_default, $TemplateProfile->global_id, $TemplateProfile->created_by, $TemplateProfile->created_at, $TemplateProfile->updated_by, $TemplateProfile->updated_at, $TemplateProfile->profile_link);
    return $TemplateProfile;
}

// returns formatted single template object
function templateObj($templateObj)
{
    $templateObj->company_logo = image_url($templateObj->company_logo);
    $templateObj->profile_image = image_url($templateObj->profile_image);
    $templateObj->profile_banner = image_url($templateObj->profile_banner);
    $templateObj->save_contact_button = true_false($templateObj->show_contact);
    $templateObj->connect_button = true_false($templateObj->show_connect);
    unset($templateObj->show_connect, $templateObj->show_contact);

    $profiles = CustomerProfileTemplate::where('user_template_id', $templateObj->id)->get();
    if (!empty($profiles)) {
        foreach ($profiles as $i => $Obj) {
            $ProfileTemplateObj = CustomerProfileTemplateObj($Obj);
            unset($profiles[$i]);
            $profiles[$i] = $ProfileTemplateObj;
        }
    }

    $templateObj->links = $profiles;
    $templateObj->assignees_ids = getAssigneeIDs($templateObj->id);
    $templateObj->settings = templateSettingsObject($templateObj);

    unset($templateObj->section_color, $templateObj->profile_color, $templateObj->border_color, $templateObj->background_color, $templateObj->button_color, $templateObj->text_color, $templateObj->photo_border_color, $templateObj->color_link_icons, $templateObj->background_image, $templateObj->created_by, $templateObj->created_at, $templateObj->updated_by, $templateObj->updated_at);

    return $templateObj;
}

// returns formatted colors list
function templateSettingsObject($template)
{
    $settings = [];
    $settings['section_color'] = $template->section_color;
    $settings['profile_color'] = $template->profile_color;
    $settings['border_color'] = $template->border_color;
    $settings['background_color'] = $template->background_color;
    $settings['button_color'] = $template->button_color;
    $settings['text_color'] = $template->text_color;
    $settings['photo_border_color'] = $template->photo_border_color;
    // $settings['background_image'] = image_url($template->background_image);
    $settings['color_link_icons'] = $template->color_link_icons;
    $_settings['colors'] = $settings;

    return $_settings;
}

// returns formatted single template profile object
function CustomerProfileTemplateObj($ProfileTemplateObj)
{
    $Profile = Profile::where('profile_code', $ProfileTemplateObj->profile_code)->first();

    $ProfileTemplateObj->icon_url = $ProfileTemplateObj->icon != '' ? icon_url() . $ProfileTemplateObj->icon : icon_url() . $Profile->icon;;
    $ProfileTemplateObj->value = $ProfileTemplateObj->profile_link;
    $ProfileTemplateObj->profile_link = ($ProfileTemplateObj->profile_code != 'file') ? $Profile->base_url . $ProfileTemplateObj->profile_link : $ProfileTemplateObj->file_image;
    $ProfileTemplateObj->href = $ProfileTemplateObj->profile_link;
    $ProfileTemplateObj->is_highlighted = true_false($ProfileTemplateObj->is_focused == null ? 0 : $ProfileTemplateObj->is_focused);
    $ProfileTemplateObj->visible = true_false($ProfileTemplateObj->status);
    $ProfileTemplateObj->type = $Profile->type;
    $ProfileTemplateObj->template_id = $ProfileTemplateObj->user_template_id;

    unset($ProfileTemplateObj->icon, $ProfileTemplateObj->profile_link, $ProfileTemplateObj->user_template_id, $ProfileTemplateObj->file_image, $ProfileTemplateObj->is_business, $ProfileTemplateObj->is_focused, $ProfileTemplateObj->global_id, $ProfileTemplateObj->created_by, $ProfileTemplateObj->created_at, $ProfileTemplateObj->updated_by, $ProfileTemplateObj->updated_at, $ProfileTemplateObj->is_default, $ProfileTemplateObj->is_direct, $ProfileTemplateObj->user_id, $ProfileTemplateObj->status);

    return $ProfileTemplateObj;
}

// model TemplateProfile exists
function templateExists($TemplateId, $ParentId)
{
    $UserTemplate = UserTemplate::where('id', $TemplateId)->where('user_id', $ParentId);
    if ($UserTemplate->count() == 0) {
        $data['success'] = FALSE;
        $data['message'] = 'Invalid Template.';
        $data['data'] = (object)[];
    } else {
        $data['success'] = TRUE;
        $data['template'] =  $UserTemplate->first();
    }
    return $data;
}

//create or update values
function createOrUpdateTemplateProfile($record, $UserTemplateID, $token, $action = 'add')
{
    if ($action == 'update') {
        $Obj = CustomerProfileTemplate::where('id', $record->id);
        if ($Obj->count() > 0) {
            $Obj = $Obj->first();
            $Obj->profile_link = (isset($record->profile_link)) ? $record->profile_link : $Obj->profile_link;
            $Obj->title = (isset($record->title)) ? $record->title : $Obj->title;;
            $Obj->updated_by = $token->id;
        } else {
            return [];
        }
    } else {
        $Obj = new CustomerProfileTemplate();
        $Obj->profile_link = (isset($record->profile_link)) ? $record->profile_link : NULL;
        $Obj->profile_code = $record->profile_code;
        $Obj->title = (isset($record->title)) ? $record->title : NULL;
        $Obj->sequence = maxTemplateProfileSequence($UserTemplateID);
        $Obj->created_by = $token->id;
    }

    $Obj->user_id = 0;
    $Obj->is_business = 0;
    $Obj->status = 1;
    $Obj->is_default = 0;
    $Obj->user_template_id = $UserTemplateID;
    $Obj->save();

    return $Obj;
}

// create or update settings value
function createOrUpdateSettings($key, $value, $user_id, $token)
{
    if (in_array($key, ['open_direct'])) {
        $userObj = User::where('id', $user_id);
        if ($userObj->count() > 0) {
            $userObj = $userObj->first();
            $userObj->$key = $value;
            $userObj->updated_by = $token->id;
            $userObj->save();
            return $userObj;
        } else {
            return [];
        }
    } else {
        $userObj = UserSettings::where('user_id', $user_id);
        if ($userObj->count() > 0) {
            $userObj = $userObj->first();
            $userObj->$key = $value;
            $userObj->updated_by = $token->id;
            $userObj->save();
        } else {
            if ($user_id != 0 && $user_id != '' && $user_id != null) {
                $userObj = new UserSettings();
                $userObj->$key = $value;
                $userObj->user_id = $user_id;
                if ($key != 'color_link_icons') {
                    $userObj->color_link_icons = 0;
                }
                $userObj->created_by = $token->id;
                $userObj->save();
            } else {
                return [];
            }
        }
        return $userObj;
    }
}

// returns max value
function maxSequence($UserID)
{
    $maxProfileSequence = CustomerProfile::select(\DB::raw('ifnull(MAX(sequence),-1) as sequence'))->where('user_id', $UserID)->where('profile_code', '!=', 'contact-card')->first();

    return (int) $maxProfileSequence->sequence + 1;
}

// returns max value
function maxTemplateProfileSequence($UserTemplateID)
{
    $maxProfileSequence = CustomerProfileTemplate::select(\DB::raw('ifnull(MAX(sequence),-1) as sequence'))->where('user_template_id', $UserTemplateID)->first();

    return (int) $maxProfileSequence->sequence + 1;
}

// unset values from model objects

function unsetTemplateObjValue($UserTemplate)
{
    unset($UserTemplate->section_color, $UserTemplate->profile_color, $UserTemplate->border_color, $UserTemplate->background_color, $UserTemplate->button_color, $UserTemplate->text_color, $UserTemplate->photo_border_color, $UserTemplate->color_link_icons, $UserTemplate->background_image, $UserTemplate->show_contact, $UserTemplate->show_connect);

    return $UserTemplate;
}
