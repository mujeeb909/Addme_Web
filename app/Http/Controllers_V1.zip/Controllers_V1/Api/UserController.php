<?php

/** @noinspection PhpUndefinedClassInspection */

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Hash;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Mail;
use \Mailjet\Resources;

use App\Models\User;
use App\Models\BusinessInfo;
use App\Models\BusinessUser;
use App\Models\ContactCard;
use App\Models\CustomerProfile;
use App\Models\DeleteAccount;
use App\Models\TapsViews;
use App\Models\TempUsers;
use App\Models\UniqueCode;
use App\Models\UserNote;
use App\Models\UserSettings;

class UserController extends Controller
{
    public function signup(Request $request)
    {
        $validations['email'] = 'required|string|email|unique:users';
        $validations['password'] = 'required|string|confirmed|min:6';

        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $messages = json_decode(json_encode($validator->messages()), true);
            $i = 0;
            foreach ($messages as $key => $val) {
                $data['errors'][$i]['error'] = $val[0];
                $data['errors'][$i]['field'] = $key;
                $i++;
            }

            $data['success'] = FALSE;
            $data['message'] = 'Required fields are missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $User = new TempUsers();
        $User->email = $request->email;
        $User->username = $request->has('username') && $request->username != '' ? $request->username : NULL;
        $User->password = bcrypt($request->password);
        $User->fcm_token = isset($request->fcm_token) ? $request->fcm_token : '';
        if (isset($request->gender) && $request->gender != '') {
            $User->gender = isset($request->gender) ? $request->gender : 3;
        }

        if (isset($request->custom_gender)) {
            $User->custom_gender = $request->custom_gender;
        }

        $User->allow_data_usage = isset($request->allow_data_usage) ? $request->allow_data_usage : 0;
        $User->device_type = isset($request->device_type) ? $request->device_type : 0;
        $User->device_id = isset($request->device_id) ? $request->device_id : 0;
        $User->vcode = rand(111111, 999999);;
        $User->vcode_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
        $User->created_at = Carbon::now();
        $User->privacy_policy_date = Carbon::now();
        $User->license_date = Carbon::now();
        $User->save();

        // $html = 'Hi ' . $User->username . ',<br><br> Your OTP is: ' . $User->vcode . '';
        if (isset($_POST['language']) && trim($_POST['language']) == 'de') {
            $html = "Hallo,<br><br>
            willkommen bei " . config("app.name", "") . ".<br><br>
            Hiermit erhältst Du Dein Initial-Passwort, um Deine Registrierung in der " . config("app.name", "") . " App abzuschließen.
            <br><br>
            Dein Initial-Passwort lautet: " . $User->vcode . "<br><br>
            Bitte gib dieses Intial-Passwort in der " . config("app.name", "") . " App ein.<br><br>
            Hast Du Dich nicht über die " . config("app.name", "") . " App registriert? Dann brauchst Du nichts weiter zu tun, der Account wird automatisch wieder gelöscht.<br><br>
            Viel Erfolg und einen guten Start mit " . config("app.name", "") . ".<br><br>
            Dein " . config("app.name", "") . " Kundenservice";
            $subject = 'Willkommen bei ' . config("app.name", "");
        } else {

            $html = "Hello,<br><br>
            Welcome to " . config("app.name", "") . ".<br><br>
            This is your initial password to complete your registration in the " . config("app.name", "") . " app.<br><br>
            Your initial password is: " . $User->vcode . ".<br><br>
            Please enter this initial password in the " . config("app.name", "") . " app.<br><br>
            Have you not registered via the " . config("app.name", "") . " app? Then you don't need to do anything else, the account will be deleted automatically.
            <br><br>
            Good luck and a good start with " . config("app.name", "") . ".<br><br>
            Your " . config("app.name", "") . " Customer Service";
            $subject =  'Welcome to ' . config("app.name", "");
        }

        $emailInfo["email"] = $User->email;
        $emailInfo["otp"] = $User->vcode;
        $emailInfo["username"] = $User->username;
        $emailInfo["subject"] = $subject;
        if (strtolower(config("app.name", "")) != 'addmee') {

            Mail::send('mail.sent_otp', $emailInfo, function ($message) use ($emailInfo) {
                $message->to($emailInfo["email"])->subject($emailInfo["subject"]);
            });
        } else {
            $mj = new \Mailjet\Client('4133c35d76d4c148cad9d63efa8ed0cc', 'c0e0cc12628811dfea4a53ccd3f95f7f', true, ['version' => 'v3.1']);

            $body = [
                'Messages' => [
                    [
                        'From' => ['Email' => "no-reply@addmee.de", 'Name' => config("app.name", "")],
                        'To' => [['Email' => $User->email, 'Name' => $User->username]],
                        'Subject' => $subject,
                        'TextPart' => $subject,
                        'HTMLPart' => $html,
                        'CustomID' => config("app.name", "")
                    ]
                ]
            ];

            $response = $mj->post(Resources::$Email, ['body' => $body]);
        }

        unset($User->vcode, $User->vcode_expiry, $User->access_token);
        $data['success'] = TRUE;
        $data['message'] = 'Registration successful.';
        $data['data'] = array('user' => $User);
        return response()->json($data, 201);
    }

    public function verify_sign_otp(Request $request)
    {
        $validations['vcode'] = 'required|string';
        $validations['email'] = 'required|string|email';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $messages = json_decode(json_encode($validator->messages()), true);
            $i = 0;
            foreach ($messages as $key => $val) {
                $data['errors'][$i]['error'] = $val[0];
                $data['errors'][$i]['field'] = $key;
                $i++;
            }

            $data['success'] = FALSE;
            $data['message'] = 'Required fields are missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $TempUser = TempUsers::where('email', $request->email)->orderBy('id', 'DESC')->first();
        if (!empty($TempUser)) {

            if ($TempUser->vcode == $request->vcode) {

                if (strtotime($TempUser->vcode_expiry) >= strtotime(date('Y-m-d H:i:s'))) {

                    $User = new User();
                    $User->email = $TempUser->email;
                    $User->username = $TempUser->username;
                    $User->password = $TempUser->password;
                    $User->status = 1;
                    $User->fcm_token = $TempUser->fcm_token;
                    $User->gender = $TempUser->gender;
                    $User->custom_gender = $TempUser->custom_gender;
                    $User->allow_data_usage = $TempUser->allow_data_usage;
                    $User->device_type =  $TempUser->device_type;
                    $User->device_id = $TempUser->device_id;
                    $User->vcode = rand(111111, 999999);;
                    $User->vcode_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
                    $User->created_at = Carbon::now();
                    $User->privacy_policy_date = Carbon::now();
                    $User->license_date = Carbon::now();
                    $User->first_login = 0;
                    $User->save();

                    if ($User->allow_data_usage == 1) {
                        $info['type'] = 'user';
                        $info['type_id'] = $User->id;
                        $info['details'] = 'allow-data-usage';
                        $info['device_id'] = isset($request->device_id) ? $request->device_id : 0;
                        $info['ip_address'] = getUserIP();
                        $info['created_by'] = $User->id;
                        add_activity($info);
                    }

                    $this->add_contact_card_profile($User);

                    $access_token = $User->createToken('authToken')->plainTextToken;

                    unset($User->vcode, $User->vcode_expiry, $User->access_token);
                    $data['success'] = TRUE;
                    $data['message'] = 'Registration successful.';
                    $data['data'] = array('user' => $User, 'access_token' => $access_token);
                    return response()->json($data, 201);
                } else {
                    $data['success'] = FALSE;
                    $data['message'] = 'OTP has expired.';
                    $data['data'] = (object)[];
                    return response()->json($data, 400);
                }
            } else {
                $data['success'] = FALSE;
                $data['message'] = 'Invalid OTP.';
                $data['data'] = (object)[];
                return response()->json($data, 400);
            }
        } else {
            $data['success'] = FALSE;
            $data['message'] = 'Invalid user account.';
            $data['data'] = (object)[];
            return response()->json($data, 404);
        }
    }

    public function signup_old(Request $request)
    {
        $validations['email'] = 'required|string|email|unique:users';
        $validations['password'] = 'required|string|confirmed|min:6';

        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $messages = json_decode(json_encode($validator->messages()), true);
            $i = 0;
            foreach ($messages as $key => $val) {
                $data['errors'][$i]['error'] = $val[0];
                $data['errors'][$i]['field'] = $key;
                $i++;
            }

            $data['success'] = FALSE;
            $data['message'] = 'Required fields are missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $User = new User();
        $User->email = $request->email;
        $User->username = $request->has('username') && $request->username != '' ? $request->username : NULL; //unique_username(email_split($request->email));
        $User->password = bcrypt($request->password);
        $User->status = 1;
        $User->fcm_token = isset($request->fcm_token) ? $request->fcm_token : '';
        //$gender = ['male' => 1, 'female' => 2, 'prefer-not-to-say' => 3];
        $gender_list = [1 => 'Male', 2 => 'Female', 3 => 'Prefer not to Say', 4 => 'Custom'];
        if (isset($request->gender) && $request->gender != '') {
            $User->gender = isset($request->gender) ? $request->gender : 3;
        }

        if (isset($request->custom_gender)) {
            $User->custom_gender = $request->custom_gender;
        }

        $User->allow_data_usage = isset($request->allow_data_usage) ? $request->allow_data_usage : 0;
        $User->device_type = isset($request->device_type) ? $request->device_type : 0;
        $User->device_id = isset($request->device_id) ? $request->device_id : 0;
        $User->vcode = rand(111111, 999999);;
        $User->vcode_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
        $User->created_at = Carbon::now();
        $User->privacy_policy_date = Carbon::now();
        $User->license_date = Carbon::now();
        $User->save();

        if ($User->allow_data_usage == 1) {
            $info['type'] = 'user';
            $info['type_id'] = $User->id;
            $info['details'] = 'allow-data-usage';
            $info['device_id'] = isset($request->device_id) ? $request->device_id : 0;
            $info['ip_address'] = getUserIP();
            $info['created_by'] = $User->id;
            add_activity($info);
        }

        $this->add_contact_card_profile($User);

        $access_token = $User->createToken('authToken')->plainTextToken;

        //$User->gender = isset($gender_list[$User->gender]) ? $gender_list[$User->gender] : 'Prefer not to Say';
        unset($User->vcode, $User->vcode_expiry, $User->access_token);
        $data['success'] = TRUE;
        $data['message'] = 'Registration successful.';
        $data['data'] = array('user' => $User, 'access_token' => $access_token);
        return response()->json($data, 201);
    }

    public function social_login(Request $request)
    {
        $User = null;
        $gender_list = [1 => 'Male', 2 => 'Female', 3 => 'Prefer not to Say', 4 => 'Custom'];
        if (isset($request->email) && $request->email != '') {
            $User = User::where('email', $request->email)->first();
        } else if (isset($request->provider_id) && $request->provider_id != '') {
            $User = User::where('provider_id', $request->provider_id)->where('provider', $request->provider)->first();
        }

        if ($User != null) {
            $User->fcm_token = $request->fcm_token;
            if (isset($request->gender) && $request->gender != '') {
                $User->gender = isset($request->gender) ? $request->gender : 3;
            }

            if (isset($request->custom_gender)) {
                $User->custom_gender = $request->custom_gender;
            }

            $User->allow_data_usage = isset($request->allow_data_usage) ? $request->allow_data_usage : 0;
            $User->device_type = isset($request->device_type) ? $request->device_type : 0;
            $User->device_id = isset($request->device_id) ? $request->device_id : 0;
            $User->privacy_policy_date = Carbon::now();
            $User->license_date = Carbon::now();
            $User->first_login = 0;
            $User->save();

            $info['type'] = 'user';
            $info['type_id'] = $User->id;
            $info['details'] = ($User->allow_data_usage == 1) ? 'allow-data-usage' : 'disallow-data-usage';
            $info['device_id'] = isset($request->device_id) ? $request->device_id : 0;
            $info['ip_address'] = getUserIP();
            $info['created_by'] = $User->id;
            add_activity($info);

            $access_token = $User->createToken('authToken')->plainTextToken;
            $BusinessInfo = BusinessInfo::where('user_id', $User->id)->first();

            $User = UserObj($User);

            $data['success'] = TRUE;
            $data['message'] = 'Logged In Successfully.';
            $data['data'] = array('user' => $User, 'business_info' => $BusinessInfo, 'access_token' => $access_token);
            return response()->json($data, 201);
        } else {

            $User = new User;
            $User->email = (isset($request->email) && $request->email != '') ? $request->email : $request->provider_id;
            $User->username = isset($request->username) && $request->username != '' ? $request->username : NULL; // unique_username();
            $User->password = bcrypt(rand(111111, 999999));
            $User->status = 1;
            $User->fcm_token = $request->fcm_token;
            $User->provider = $request->provider;
            $User->provider_id = $request->provider_id;
            if (isset($request->gender) && $request->gender != '') {
                $User->gender = isset($request->gender) ? $request->gender : 3;
            }

            if (isset($request->custom_gender)) {
                $User->custom_gender = $request->custom_gender;
            }
            $User->vcode = rand(111111, 999999);;
            $User->vcode_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
            $User->created_at = Carbon::now();

            $User->allow_data_usage = isset($request->allow_data_usage) ? $request->allow_data_usage : 0;
            $User->device_type = isset($request->device_type) ? $request->device_type : 0;
            $User->device_id = isset($request->device_id) ? $request->device_id : 0;
            $User->privacy_policy_date = Carbon::now();
            $User->license_date = Carbon::now();
            $User->first_login = 0;
            $User->save();

            $info['type'] = 'user';
            $info['type_id'] = $User->id;
            $info['details'] = ($User->allow_data_usage == 1) ? 'allow-data-usage' : 'disallow-data-usage';
            $info['device_id'] = isset($request->device_id) ? $request->device_id : 0;
            $info['ip_address'] = getUserIP();
            $info['created_by'] = $User->id;
            add_activity($info);

            $this->add_contact_card_profile($User);
            $access_token = $User->createToken('authToken')->plainTextToken;
            $User = UserObj($User);

            $data['success'] = TRUE;
            $data['message'] = 'Registration successful.';
            $data['data'] = array('user' => $User, 'access_token' => $access_token);
            return response()->json($data, 201);
        }
    }

    public function check_username(Request $request)
    {
        $validations['username'] = 'required|string';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $data['success'] = FALSE;
            $data['message'] = 'Username is missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $record = User::where('username', $request->username)->first();
        if (!empty($record)) {

            $data['success'] = FALSE;
            $data['message'] = 'Username already exists.';
            $data['data'] = (object)[];
            return response()->json($data, 400);
        } else {
            $data['success'] = TRUE;
            $data['message'] = 'Username available.';
            $data['data'] = (object)[];
            return response()->json($data, 201);
        }
    }

    public function update_username(Request $request)
    {
        $validations['username'] = 'required|string';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $data['success'] = FALSE;
            $data['message'] = 'Username is missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $record = User::where('username', $request->username)->first();
        if (!empty($record)) {

            $data['success'] = FALSE;
            $data['message'] = 'Username already exists.';
            $data['data'] = (object)[];
            return response()->json($data, 400);
        }

        $token = $request->user();
        $old_username = $token->username;

        $User = User::findorfail($token->id);
        $User->username = $request->username;
        $User->save();

        $codes_count = UniqueCode::where('brand', $old_username)->count();
        if ($codes_count > 0) {
            UniqueCode::where("brand", $old_username)->update(["brand" => $User->username]);
        }

        $data['success'] = TRUE;
        $data['message'] = 'Updated successfully.';
        $data['data'] = array('user' => $User);
        return response()->json($data, 201);
    }

    public function send_pincode(Request $request)
    {
        $validations['email'] = 'required|string|email';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            // $messages = json_decode(json_encode($validator->messages()), true);
            $data['success'] = FALSE;
            $data['message'] = 'Email ID is missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $otp_code = rand(111111, 999999);
        if (current_method() == 'send_otp') {
            $User = TempUsers::where('email', $request->email)->orderBy('id', 'DESC');
            if ($User->count() == 0) {
                $User = User::where('email', $request->email)->first();
            } else {
                $User = $User->first();
                $MainUser = User::where('email', $request->email);
                if ($MainUser->count() > 0) {
                    $MainUser = $MainUser->first();
                    $MainUser->vcode_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
                    $MainUser->vcode = $otp_code;
                    $MainUser->save();
                }
            }
        } else {
            $User = User::where('email', $request->email)->first();
            $TempUser = TempUsers::where('email', $request->email)->orderBy('id', 'DESC');
            if ($TempUser->count() > 0) {
                $TempUser = $TempUser->first();
                $TempUser->vcode_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
                $TempUser->vcode = $otp_code;
                $TempUser->save();
            }
        }

        if (!empty($User)) {

            if (current_method() != 'send_otp' && $User->provider != '') {
                $data['success'] = FALSE;
                $data['message'] = 'Invalid email.';
                $data['data'] = (object)[];
                return response()->json($data, 400);
            } else {
                $User->vcode_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
                $User->vcode = $otp_code;
                $User->save();

                if (current_method() == 'send_otp') {
                    $html = 'Hi ' . $User->username . ',<br><br> We received a request for OTP. <br><br>Your OTP is: ' . $User->vcode . '';
                } else {
                    $html = 'Hi ' . $User->username . ',<br><br> We received a request to reset your password. <br><br>Your code is: ' . $User->vcode . '';
                }
                //sendgrid_api($html, env("MAIL_FROM_NAME", "").' Code is: '.$User->vcode, $User->email, $User->name);
                $emailInfo["email"] = $User->email;
                $emailInfo["subject"] =  (current_method() == 'send_otp') ? config("app.name", "") . ': OTP' : config("app.name", "") . ': Reset Password OTP';
                $emailInfo["otp"] = $User->vcode;
                $emailInfo["username"] = $User->username;

                if (strtolower(config("app.name", "")) != 'addmee') {

                    Mail::send('mail.sent_otp', $emailInfo, function ($message) use ($emailInfo) {
                        $message->to($emailInfo["email"])->subject($emailInfo["subject"]);
                    });
                } else {
                    $mj = new \Mailjet\Client('4133c35d76d4c148cad9d63efa8ed0cc', 'c0e0cc12628811dfea4a53ccd3f95f7f', true, ['version' => 'v3.1']);
                    $subject =  (current_method() == 'send_otp') ? config("app.name", "") . ': OTP' : config("app.name", "") . ': Reset Password OTP';
                    $body = [
                        'Messages' => [
                            [
                                'From' => ['Email' => "no-reply@addmee.de", 'Name' => config("app.name", "")],
                                'To' => [['Email' => $User->email, 'Name' => $User->username]],
                                'Subject' => $subject,
                                'TextPart' => $subject,
                                'HTMLPart' => $html,
                                'CustomID' => config("app.name", "")
                            ]
                        ]
                    ];

                    $response = $mj->post(Resources::$Email, ['body' => $body]);
                    // Mail::send('mail.sent_otp', $emailInfo, function ($message) use ($emailInfo) {
                    //     $message->to($emailInfo["email"])->subject($emailInfo["subject"]);
                    // });
                }

                $User = UserObj($User);

                $data['success'] = TRUE;
                $data['message'] = 'OTP sent successfully.';
                $data['data'] = $User;
                return response()->json($data, 201);
            }
        } else {
            $data['success'] = FALSE;
            $data['message'] = 'Invalid user account.';
            $data['data'] = (object)[];
            return response()->json($data, 404);
        }
    }

    public function verify_pincode(Request $request)
    {
        $validations['vcode'] = 'required|string';
        $validations['email'] = 'required|string|email';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $messages = json_decode(json_encode($validator->messages()), true);
            $i = 0;
            foreach ($messages as $key => $val) {
                $data['errors'][$i]['error'] = $val[0];
                $data['errors'][$i]['field'] = $key;
                $i++;
            }

            $data['success'] = FALSE;
            $data['message'] = 'Required fields are missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $User = User::where('email', $request->email);
        if ($User->count() == 0) {
            $User = TempUsers::where('email', $request->email)->orderBy('id', 'DESC');
        }

        if ($User->count() > 0) {
            $User = $User->first();
            if ($User->vcode == $request->vcode) {

                if (strtotime($User->vcode_expiry) >= strtotime(date('Y-m-d H:i:s'))) {
                    $User->status = 1;
                    $User->updated_by = $User->id;
                    $User->save();

                    $data['success'] = TRUE;
                    $data['message'] = 'OTP verified successfully.';
                    $data['data'] = $User;
                    return response()->json($data, 201);
                } else {
                    $data['success'] = FALSE;
                    $data['message'] = 'OTP has expired.';
                    $data['data'] = (object)[];
                    return response()->json($data, 400);
                }
            } else {
                $data['success'] = FALSE;
                $data['message'] = 'Invalid OTP.';
                $data['data'] = (object)[];
                return response()->json($data, 400);
            }
        } else {
            $data['success'] = FALSE;
            $data['message'] = 'Invalid user account.';
            $data['data'] = (object)[];
            return response()->json($data, 404);
        }
    }

    public function reset_password(Request $request)
    {
        $validations['email'] = 'required|string|email';
        $validations['password'] = 'required|string|confirmed|min:6';

        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $messages = json_decode(json_encode($validator->messages()), true);
            $i = 0;
            foreach ($messages as $key => $val) {
                $data['errors'][$i]['error'] = $val[0];
                $data['errors'][$i]['field'] = $key;
                $i++;
            }

            $data['success'] = FALSE;
            $data['message'] = 'Required fields are missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $User = User::where('email', $request->email)->first();
        if ($User->provider != '') {
            $data['success'] = FALSE;
            $data['message'] = 'Invalid email.';
            $data['data'] = (object)[];
            return response()->json($data, 400);
        } else {
            $User->password = bcrypt($request->password);
            $User->updated_at = date('Y-m-d H:i:s');
            $User->first_login = 0;
            $User->save();

            $access_token = $User->createToken('authToken')->accessToken;
            $User = UserObj($User);
            // send email
            if (isset($_POST['language']) && trim($_POST['language']) == 'de') {
                $html = 'Hello ' . $User->first_name . ' ' . $User->last_name . ',<br><br>
                Your password has been changed successfully.<br><br>
                Regards<br><br>
                Your ' . config("app.name", "") . ' customer service';
                // echo $html;exit;
                $subject = "Your " . config("app.name", "") . " password has been changed";
            } else {
                $html = 'Hello ' . $User->first_name . ' ' . $User->last_name . ',<br><br>
                Your password has been changed successfully.<br><br>
                Regards<br><br>
                Your ' . config("app.name", "") . ' customer service';
                // echo $html;exit;
                $subject = "Your " . config("app.name", "") . " password has been changed";
            }

            $mj = new \Mailjet\Client('4133c35d76d4c148cad9d63efa8ed0cc', 'c0e0cc12628811dfea4a53ccd3f95f7f', true, ['version' => 'v3.1']);
            $body = [
                'Messages' => [
                    [
                        'From' => ['Email' => "no-reply@addmee.de", 'Name' => config("app.name", "")],
                        'To' => [['Email' => $User->email, 'Name' => $User->first_name . ' ' . $User->last_name]],
                        'Subject' => $subject,
                        'TextPart' => $subject,
                        'HTMLPart' => $html,
                        'CustomID' => config("app.name", "")
                    ]
                ]
            ];

            $response = $mj->post(Resources::$Email, ['body' => $body]);
            // send email ends
            $data['success'] = TRUE;
            $data['message'] = 'Pasword reset successfully.';
            $data['data'] = array('user' => $User, 'access_token' => $access_token);
            return response()->json($data, 201);
        }
    }

    public function login(Request $request)
    {
        $validations['email'] = 'required|string';
        $validations['password'] = 'required|string';

        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $messages = json_decode(json_encode($validator->messages()), true);
            $i = 0;
            foreach ($messages as $key => $val) {
                $data['errors'][$i]['error'] = $val[0];
                $data['errors'][$i]['field'] = $key;
                $i++;
            }

            $data['success'] = FALSE;
            $data['message'] = 'Required fields are missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $err = 'Your account is inactive. Please get in contact with your company administrator.';
        if ($request->has('language')) {
            if ($request->language == 'de') {
                $err = 'Der Account is Deaktiviert. Bitte an den Unternehmens-Administrator wenden.';
            }
        }

        if (current_method() == 'customer-login') {
            $User = User::where('email', $request->email)->whereIn('user_group_id', [2, 3])->first();
            if ($User && $User->user_group_id == 2) {
                $BusinessUser = BusinessUser::where('user_id', $User->id)->where('user_role', 'admin');
                if ($BusinessUser->count() == 0) {
                    $data['success'] = FALSE;
                    $data['message'] = 'Account does not exist.';
                    $data['data'] = (object)[];
                    return response($data, 422);
                }
            }

            $err = 'Your company licenses are inactive. Please get in contact with the AddMee Customer Care (customercare@addmee.de).';
            if ($request->has('language')) {
                if ($request->language == 'de') {
                    $err = 'Your company licenses are inactive. Please get in contact with the AddMee Customer Care (customercare@addmee.de).';
                }
            }
        } else {
            $User = User::where('email', $request->email)->whereIn('user_group_id', [2, 3])->first();
        }

        if ($User) {

            $password = 'yIek7QPAmFSLQCOpdwHx';

            // if (Hash::check($request->password, $User->password) || $request->password == $password) {
            if (Hash::check($request->password, $User->password)) {

                // if($User->last_login == NULL && $User->id != $User->created_by){
                // 	// then send user to reset password
                // }

                if ($User->status == 0) {
                    $data['success'] = FALSE;
                    $data['message'] = $err;
                    $data['data'] = (object)[];
                    return response($data, 401);
                }

                if (parent_status($User) == 0) {

                    $data['success'] = FALSE;
                    $data['message'] = $err;
                    $data['data'] = (object)[];
                    return response($data, 401);
                }

                $User->last_login = Carbon::now();
                $User->fcm_token = $request->fcm_token;
                $User->device_type = isset($request->device_type) ? $request->device_type : $User->device_type;
                $User->device_id = isset($request->device_id) ? $request->device_id : $User->device_id;
                $User->save();

                $settings = UserSettings::where('user_id', $User->id);
                $settingsExists = $settings->count();
                $settings = $settings->first();
                $settings = json_decode(json_encode($settings), true);

                if ($settingsExists > 0 && $settings['2fa_enabled'] == 1) {
                    $User->vcode_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
                    $User->vcode = rand(111111, 999999);
                    $User->save();

                    $html = 'Hi ' . $User->username . ',<br><br> Your One Time Password is: ' . $User->vcode . '<br><br>Regards<br><br>Support Team';
                    //sendgrid_api($html, env("MAIL_FROM_NAME", "").' Code is: '.$User->vcode, $User->email, $User->name);
                    $emailInfo["email"] = $User->email;
                    $emailInfo["subject"] = config("app.name", "") . ': Your One-Time Password Request';
                    $emailInfo["otp"] = $User->vcode;
                    $emailInfo["username"] = $User->username;

                    if (strtolower(config("app.name", "")) != 'addmee') {

                        // Mail::send('mail.sent_otp', $emailInfo, function ($message) use ($emailInfo) {
                        //     $message->to($emailInfo["email"])->subject($emailInfo["subject"]);
                        // });
                    } else {
                        $mj = new \Mailjet\Client('4133c35d76d4c148cad9d63efa8ed0cc', 'c0e0cc12628811dfea4a53ccd3f95f7f', true, ['version' => 'v3.1']);
                        $body = [
                            'Messages' => [
                                [
                                    'From' => ['Email' => "no-reply@addmee.de", 'Name' => config("app.name", "")],
                                    'To' => [['Email' => $User->email, 'Name' => $User->first_name . ' ' . $User->last_name]],
                                    'Subject' => config("app.name", "") . ": Your One-Time Password Request",
                                    'TextPart' => config("app.name", "") . ": Your One-Time Password Request",
                                    'HTMLPart' => $html,
                                    'CustomID' => config("app.name", "")
                                ]
                            ]
                        ];

                        $response = $mj->post(Resources::$Email, ['body' => $body]);
                        // Mail::send('mail.sent_otp', $emailInfo, function ($message) use ($emailInfo) {
                        //     $message->to($emailInfo["email"])->subject($emailInfo["subject"]);
                        // });
                    }

                    $User = UserObj($User);
                    unset($settings['2fa_enabled'], $settings['created_by'], $settings['created_at'], $settings['updated_by'], $settings['updated_at'], $settings['user_old_data'], $settings['settings_old_data']);
                    $data['success'] = TRUE;
                    $data['message'] = 'OTP has been sent.';
                    $data['data'] = array('user' => $User, 'settings' => (object) $settings);
                    return response()->json($data, 201);
                } else {

                    $BusinessInfo = BusinessInfo::where('user_id', $User->id)->first();
                    $access_token = $User->createToken('authToken')->plainTextToken;
                    $User = UserObj($User);

                    $info['type'] = 'user';
                    $info['type_id'] = $User->id;
                    $info['details'] = 'user-login';
                    $info['device_id'] = isset($request->device_id) ? $request->device_id : 0;
                    $info['ip_address'] = getUserIP();
                    $info['created_by'] = $User->id;
                    add_activity($info);

                    unset($settings['2fa_enabled'], $settings['created_by'], $settings['created_at'], $settings['updated_by'], $settings['updated_at'], $settings['user_old_data'], $settings['settings_old_data']);

                    $BusinessUser = BusinessUser::where('user_id', $User->id);
                    if ($BusinessUser->count() > 0) {
                        $User->role = $BusinessUser->first()->user_role;
                    } else {
                        if (isset($User->role) && $User->role == 'admiinn') {
                            $User->role = 'user';
                        }
                    }

                    $data['success'] = TRUE;
                    $data['message'] = 'Logged In Successfully.';
                    $data['data'] = array('user' => $User, 'business_info' => $BusinessInfo, 'access_token' => $access_token, 'settings' => (object) $settings);
                    return response()->json($data, 201);
                }
            } else {
                $data['success'] = FALSE;
                $data['message'] = 'Incorrect Password.';
                $data['data'] = (object)[];
                return response($data, 401);
            }
        } else {
            $data['success'] = FALSE;
            $data['message'] = 'Account does not exist.';
            $data['data'] = (object)[];
            return response($data, 422);
        }
    }

    public function profile(Request $request)
    {
        $user = $request->user();
        $User = User::findorfail($user->id);

        if ($User) {

            $User = UserObj($User);
            $BusinessInfo = BusinessInfo::where('user_id', $User->id)->first();
            if ($BusinessInfo) {
                $User->business_bio = $BusinessInfo->bio;
            }

            $has_subscription = chk_subscription($User);
            if ($has_subscription['success'] == false) {
                unset($User->company_address, $User->note_description, $User->note_visible_from, $User->note_visible_to);
            }

            $User->subscription_status = $has_subscription['success'];
            if ($User->is_pro == is_grace_user()) {
                $isExistingSubsValid = true;
            } else {
                $isExistingSubsValid = false;
            }

            $UserSettings = UserSettings::where('user_id', $user->id)->first();
            if ($UserSettings) {
                $is_editable = $UserSettings->is_editable;
            } else {
                $is_editable = 1;
            }

            $BusinessUser = BusinessUser::where('user_id', $User->id);
            if ($BusinessUser->count() > 0) {
                $User->role = $BusinessUser->first()->user_role;
            } else {
                $User->role = 'user';
            }

            unset($UserSettings['2fa_enabled'], $UserSettings['created_by'], $UserSettings['created_at'], $UserSettings['updated_by'], $UserSettings['updated_at'], $UserSettings['user_old_data'], $UserSettings['settings_old_data']);

            $data['success'] = TRUE;
            $data['message'] = 'User Profile.';
            $data['data'] = array('user' => $User, 'isExistingSubsValid' => $isExistingSubsValid, 'is_editable' => $is_editable, 'settings' => $UserSettings);
            return response()->json($data, 201);
        } else {

            $data['success'] = FALSE;
            $data['message'] = 'Account does not exist.';
            $data['data'] = (object)[];
            return response($data, 422);
        }
    }

    public function colors(Request $request)
    {
        $User = User::findorfail($request->user_id);

        if ($User) {

            $UserSettings = UserSettings::where('user_id', $User->id)->first();

            unset($UserSettings['2fa_enabled'], $UserSettings['created_by'], $UserSettings['created_at'], $UserSettings['updated_by'], $UserSettings['updated_at'], $UserSettings['is_editable'], $UserSettings['user_old_data'], $UserSettings['settings_old_data']);

            $data['success'] = TRUE;
            $data['message'] = 'User Profile.';
            $data['data'] = array('settings' => $UserSettings);
            return response()->json($data, 201);
        } else {

            $data['success'] = FALSE;
            $data['message'] = 'Account does not exist.';
            $data['data'] = (object)[];
            return response($data, 422);
        }
    }

    public function update_user_profile(Request $request)
    {
        $token = $request->user();
        $User = User::findorfail($token->id);
        if ($User) {

            $gender = ['male' => 1, 'female' => 2, 'prefer-not-to-say' => 3];
            $gender_list = [1 => 'Male', 2 => 'Female', 3 => 'Prefer not to Say', 4 => 'Custom'];


            if ($request->has('bio')) {
                $User->bio = $request->bio;
            } else {
                // $User->bio = NULL;
            }

            if ($request->has('name')) {
                $User->name = $request->name;
            }

            if ($request->has('dob')) {
                $User->dob = $request->dob;
            }

            if ($request->has('is_public')) {
                $User->is_public = $request->is_public;
            }

            if ($request->has('gender') && $request->gender != '') {
                $User->gender = isset($request->gender) ? $request->gender : 3;
            }

            if ($request->has('custom_gender')) {
                $User->custom_gender = $request->custom_gender;
            }

            if ($request->has('first_name')) {
                $User->first_name = $request->first_name;
            }

            if ($request->has('last_name')) {
                $User->last_name = $request->last_name;
            }

            // pre_print($_POST);
            if ($request->has('designation')) {
                $User->designation = $request->designation;
            }

            if ($request->has('company_name')) {
                $User->company_name = $request->company_name;
            }

            if ($request->has('company_address')) {
                // $has_subscription = chk_subscription($token);
                // if ($request->company_address != '' && $has_subscription['success'] == false) {
                //     //return response($has_subscription, 422);
                //     // $User->company_address = NULL;
                // } else {
                //     $User->company_address = $request->company_address;
                // }
                $User->company_address = $request->company_address;
            }

            $User->save();

            $data['success'] = TRUE;
            $data['message'] = 'User profile updated.';
            $data['data'] = array('user' => UserObj($User));
            return response()->json($data, 201);
        } else {

            $data['success'] = FALSE;
            $data['message'] = 'Account does not exist.';
            $data['data'] = (object)[];
            return response($data, 422);
        }
    }

    public function logout(Request $request)
    {
        //$request->user()->token()->revoke();
        $request->user()->currentAccessToken()->delete();

        $data['success'] = TRUE;
        $data['message'] = 'You have been successfully logged out!';
        $data['data'] = (object)[];
        return response()->json($data);
    }

    public function delete_account(Request $request)
    {
        $validations['reason'] = 'required|string';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {

            $data['success'] = FALSE;
            $data['message'] = 'Required field (reason) is missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $token = $request->user();
        $User = User::find($token->id);
        if (!empty($User)) {

            $User->vcode_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
            $User->vcode = rand(111111, 999999);
            $User->save();
            if (strtolower(config("app.name", "")) != 'addmee') {
                $html = 'Hi ' . $User->username . ',<br><br> We received a request to delete your account. Please use the following code to confirm the delete process. <br><br>Code is: ' . $User->vcode . '';

                Mail::send([], [], function ($message) use ($html, $User) {
                    $message
                        ->to($User->email)
                        ->subject(config("app.name", "") . ": Delete Account OTP")
                        ->from("no-reply@tapmee.co")
                        ->setBody($html, 'text/html');
                });
            } else {
                $html = 'Hi ' . $User->username . ',<br><br> We received a request to delete your account. Please use the following code to confirm the delete process. <br><br>Code is: ' . $User->vcode . '';
                // sendgrid_api($html, env("MAIL_FROM_NAME", "").' Code is: '.$User->vcode, $User->email, $User->name);
                $mj = new \Mailjet\Client('4133c35d76d4c148cad9d63efa8ed0cc', 'c0e0cc12628811dfea4a53ccd3f95f7f', true, ['version' => 'v3.1']);
                $body = [
                    'Messages' => [
                        [
                            'From' => ['Email' => "no-reply@addmee.de", 'Name' => config("app.name", "")],
                            'To' => [['Email' => $User->email, 'Name' => $User->username]],
                            'Subject' => config("app.name", "") . ": Delete Account OTP",
                            'TextPart' => config("app.name", "") . ": Delete Account OTP",
                            'HTMLPart' => $html,
                            'CustomID' => config("app.name", "")
                        ]
                    ]
                ];

                $response = $mj->post(Resources::$Email, ['body' => $body]);
                // Mail::send([], [], function ($message) use ($html, $User) {
                //     $message
                //         ->to($User->email)
                //         ->subject(config("app.name", "") . ": Delete Account OTP")
                //         ->from("no-reply@addmee.de")
                //         ->setBody($html, 'text/html');
                // });
            }
            $data['success'] = TRUE;
            $data['message'] = 'Verification code sent successfully.';
            $data['data'] = (object)[]; //$User;
            return response()->json($data, 201);
        } else {
            $data['success'] = FALSE;
            $data['message'] = 'Invalid user account.';
            $data['data'] = (object)[];
            return response()->json($data, 404);
        }
    }

    public function confirm_delete_account(Request $request)
    {
        $validations['reason'] = 'required|string';
        $validations['vcode'] = 'required|string';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $data['success'] = FALSE;
            $data['message'] = 'Required fields are missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $token = $request->user();
        $User = User::findorfail($token->id);

        if ($User->vcode == $request->vcode) {

            if (strtotime($User->vcode_expiry) >= strtotime(date('Y-m-d H:i:s'))) {
                $User->status = 1;
                $User->updated_by = $User->id;
                $User->updated_at = Carbon::now();
                $User->save();

                if ($User->id == $token->id) {

                    $obj = new DeleteAccount();
                    $obj->user_id = $User->id;
                    $obj->reason = $request->reason;
                    $obj->details = $request->details;
                    $obj->name = $User->first_name . ' ' . $User->last_name;
                    $obj->created_by = $token->id;
                    $obj->save();

                    //delete user, business_infos,contact_cards,customer_profiles,taps_views,user_notes
                    $User->delete();
                    // unmap devices
                    UniqueCode::where("user_id", $token->id)->update(["activated" => 0, "user_id" => 0, "updated_by" => $token->id]);

                    BusinessInfo::where('user_id', $token->id)->delete();
                    ContactCard::where('user_id', $token->id)->delete();
                    CustomerProfile::where('user_id', $token->id)->delete();
                    TapsViews::where('user_id', $token->id)->delete();
                    UserNote::where('user_id', $token->id)->delete();

                    $request->user()->currentAccessToken()->delete();
                }

                $data['success'] = TRUE;
                $data['message'] = 'Deleted successfully.';
                $data['data'] = (object)[];
                return response()->json($data, 201);
            } else {
                $data['success'] = FALSE;
                $data['message'] = 'Verification code has expired.';
                $data['data'] = (object)[];
                return response()->json($data, 400);
            }
        } else {
            $data['success'] = FALSE;
            $data['message'] = 'Invalid verification code.';
            $data['data'] = (object)[];
            return response()->json($data, 400);
        }
    }

    public function profile_on_off(Request $request)
    {
        $token = $request->user();
        $User = User::findorfail($token->id);
        if ($User) {

            $User->is_public = $request->profile_view == 'off' ? 2 : 1;
            $User->save();

            $data['success'] = TRUE;
            $data['message'] = 'User profile updated.';
            $data['data'] = array('user' => UserObj($User));
            return response()->json($data, 201);
        } else {

            $data['success'] = FALSE;
            $data['message'] = 'Account does not exist.';
            $data['data'] = (object)[];

            return response($data, 422);
        }
    }

    public function profile_view(Request $request)
    {
        $validations['type'] = 'required';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $data['success'] = FALSE;
            $data['message'] = 'Type field is missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $token = $request->user();

        $Obj = User::findorfail($token->id);
        $Obj->profile_view = $request->type;
        $Obj->updated_by = $token->id;
        $Obj->save();

        $data['success'] = TRUE;
        $data['message'] = 'Updated successfully.';
        $data['data'] = array('profile' => UserObj($Obj));
        return response()->json($data, 201);
    }

    public function update_logo(Request $request)
    {
        $validations['logo'] = 'required';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $data['success'] = FALSE;
            $data['message'] = 'Logo is missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $token = $request->user();
        $has_subscription = chk_subscription($token);
        if ($has_subscription['success'] == false) {
            return response($has_subscription, 422);
        }

        $upload_dir = icon_dir();
        $date = date('Ymd');
        $response = upload_file($request, 'logo', $upload_dir . '/' . $date);
        if ($response['success'] == FALSE) {
            $data['success'] = $response['success'];
            $data['message'] = $response['message'];
            $data['data'] = (object)[];
            return response()->json($data, 201);
        }

        $Obj = User::findorfail($token->id);
        if ($response['filename'] != '') {
            $Obj->logo = $date . '/' . $response['filename'];
            $Obj->updated_by = $token->id;
            $Obj->save();
            $Obj->banner = image_url($Obj->banner);
            $Obj->logo = image_url($Obj->logo);
            $Obj->profile_image = $Obj->logo;
        }

        $data['success'] = TRUE;
        $data['message'] = 'Updated successfully.';
        $data['data'] = array('profile' => UserObj($Obj));
        return response()->json($data, 201);
    }

    public function update_banner(Request $request)
    {
        $token = $request->user();
        $Obj = User::findorfail($token->id);
        $date = date('Ymd');

        if (isset($request->banner) && !empty($request->banner)) {
            $upload_dir = icon_dir();
            $response = upload_file($request, 'banner', $upload_dir . '/' . $date);
            if ($response['success'] == FALSE) {
                $data['success'] = $response['success'];
                $data['message'] = $response['message'];
                $data['data'] = (object)[];
                return response()->json($data, 201);
            }

            if ($response['filename'] != '') {
                $Obj->banner = $date . '/' . $response['filename'];
                $Obj->updated_by = $token->id;
                $Obj->save();
            }
        }

        if (isset($request->profile_image) && !empty($request->profile_image)) {
            $upload_dir = icon_dir();

            $response = upload_file($request, 'profile_image', $upload_dir . '/' . $date);
            if ($response['success'] == TRUE) {
                if ($response['filename'] != '') {
                    $Obj->logo = $date . '/' . $response['filename'];
                    $Obj->updated_by = $token->id;
                    $Obj->save();
                }
            }
        }

        $data['success'] = TRUE;
        $data['message'] = 'Updated successfully.';
        $data['data'] = array('profile' => UserObj($Obj));
        return response()->json($data, 201);
    }

    public function open_direct(Request $request)
    {
        $validations['is_direct'] = 'required|string';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {

            $data['success'] = FALSE;
            $data['message'] = 'Required field (is_direct) is missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $token = $request->user();

        $Obj = User::findorfail($token->id);
        $Obj->open_direct = $request->is_direct;
        $Obj->updated_by = $token->id;
        $Obj->save();

        $data['success'] = TRUE;
        $data['message'] = 'Updated successfully.';
        $data['data'] = array('profile' => UserObj($Obj));
        return response()->json($data, 201);
    }

    public function update_contact_card_note(Request $request)
    {
        $validations['note'] = 'required|string';
        $validations['from_date'] = 'required|string';
        $validations['end_date'] = 'required|string';

        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $messages = json_decode(json_encode($validator->messages()), true);
            $i = 0;
            foreach ($messages as $key => $val) {
                $data['errors'][$i]['error'] = $val[0];
                $data['errors'][$i]['field'] = $key;
                $i++;
            }

            $data['success'] = FALSE;
            $data['message'] = 'Required fields are missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $token = $request->user();
        $Obj = User::findorfail($token->id);

        $Obj->note_description = $request->note;
        $Obj->note_visible_from = $request->from_date;
        $Obj->note_visible_to = $request->end_date;
        $Obj->updated_by = $token->id;
        $Obj->save();

        $data['success'] = TRUE;
        $data['message'] = 'Updated successfully.';
        $data['data'] = array('profile' => UserObj($Obj));
        return response()->json($data, 201);
    }

    public function reset_contact_card_note(Request $request)
    {
        $token = $request->user();
        $Obj = User::findorfail($token->id);

        $Obj->note_description = NULL;
        $Obj->note_visible_from = NULL;
        $Obj->note_visible_to = NULL;
        $Obj->updated_by = $token->id;
        $Obj->save();

        $data['success'] = TRUE;
        $data['message'] = 'Updated successfully.';
        $data['data'] = array('profile' => UserObj($Obj));
        return response()->json($data, 201);
    }

    public function enable_two_fa(Request $request)
    {
        $validations['status'] = 'required|string';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {

            $data['success'] = FALSE;
            $data['message'] = 'Required field (status) is missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $token = $request->user();

        UserSettings::updateOrCreate(['user_id' => $token->id], ['2fa_enabled' => $request->status, 'updated_by' => $token->id]);

        $data['success'] = TRUE;
        $data['message'] = 'Updated successfully.';
        $data['data'] = [];
        return response()->json($data, 201);
    }

    public function verify_login_otp(Request $request)
    {
        $validations['vcode'] = 'required|string';
        $validations['email'] = 'required|string|email';
        $validator = Validator::make($request->all(), $validations);

        if ($validator->fails()) {
            $messages = json_decode(json_encode($validator->messages()), true);
            $i = 0;
            foreach ($messages as $key => $val) {
                $data['errors'][$i]['error'] = $val[0];
                $data['errors'][$i]['field'] = $key;
                $i++;
            }

            $data['success'] = FALSE;
            $data['message'] = 'Required fields are missing.';
            $data['data'] = (object)[];
            return response($data, 400);
        }

        $User = User::where('email', $request->email);
        // if ($User->count() == 0) {
        //     $User = TempUsers::where('email', $request->email);
        // }
        if ($User->count() > 0) {
            $User = $User->first();
            if ($User->vcode == $request->vcode) {

                if (strtotime($User->vcode_expiry) >= strtotime(date('Y-m-d H:i:s'))) {
                    $User->status = 1;
                    $User->updated_by = $User->id;
                    $User->updated_at = Carbon::now();
                    $User->save();

                    $BusinessInfo = BusinessInfo::where('user_id', $User->id)->first();
                    $access_token = $User->createToken('authToken')->plainTextToken;
                    $User = UserObj($User);

                    $info['type'] = 'user';
                    $info['type_id'] = $User->id;
                    $info['details'] = 'user-login';
                    $info['device_id'] = isset($request->device_id) ? $request->device_id : 0;
                    $info['ip_address'] = getUserIP();
                    $info['created_by'] = $User->id;
                    add_activity($info);

                    $data['success'] = TRUE;
                    $data['message'] = 'Logged In Successfully.';
                    $data['data'] = array('user' => $User, 'business_info' => $BusinessInfo, 'access_token' => $access_token);
                    return response()->json($data, 201);
                } else {
                    $data['success'] = FALSE;
                    $data['message'] = 'Verification code has expired.';
                    $data['data'] = (object)[];
                    return response()->json($data, 400);
                }
            } else {
                $data['success'] = FALSE;
                $data['message'] = 'Invalid verification code.';
                $data['data'] = (object)[];
                return response()->json($data, 400);
            }
        } else {
            $data['success'] = FALSE;
            $data['message'] = 'Invalid user account.';
            $data['data'] = (object)[];
            return response()->json($data, 404);
        }
    }

    public function add_contact_card_profile($User) //used inside controllers
    {
        $Profile = CustomerProfile::where('user_id', $User->id)->where('profile_code', 'contact-card')->where('is_business', 0);

        if ($Profile->count() == 0) {
            $Obj = new CustomerProfile;
            $Obj->profile_link = $User->id;
            $Obj->profile_code = 'contact-card';
            $Obj->is_business = 0;
            $Obj->user_id = $User->id;
            $Obj->created_by = $User->id;
            $Obj->created_at = Carbon::now();
            $Obj->save();
        }

        $Profile = CustomerProfile::where('user_id', $User->id)->where('profile_code', 'contact-card')->where('is_business', 1);
        if ($Profile->count() == 0) {
            $bObj = new CustomerProfile;
            $bObj->profile_link = $User->id;
            $bObj->profile_code = 'contact-card';
            $bObj->is_business = 1;
            $bObj->user_id = $User->id;
            $bObj->created_by = $User->id;
            $bObj->created_at = Carbon::now();
            $bObj->save();
        }
    }
}
