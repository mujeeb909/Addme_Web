<!doctype html>
<html lang="en">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-0CXLG4WYLN"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-0CXLG4WYLN');
    </script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ isset($page_title) ? $page_title . ' - ' : '' }} AddMee</title>
    <meta name="description" content="{{ isset($page_title) ? $page_title . ' - ' : '' }} AddMee" />
    @if (!empty($profile))
        <meta property="og:image"
            content="{{ $profile->logo != '' ? image_url($profile->logo) : uploads_url() . 'img/addmee-logo.png' }}">
    @else
        <meta property="og:image" content="{{ uploads_url() . 'img/addmee-logo.png' }}">
    @endif
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1024">
    <meta property="og:image:height" content="1024">

    <link rel="apple-touch-icon" sizes="57x57" href="{{ asset_url() . 'apple-icon-57x57.png' }}">
    <link rel="apple-touch-icon" sizes="60x60" href="{{ asset_url() . 'apple-icon-60x60.png' }}">
    <link rel="apple-touch-icon" sizes="72x72" href="{{ asset_url() . 'apple-icon-72x72.png' }}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{ asset_url() . 'apple-icon-76x76.png' }}">
    <link rel="apple-touch-icon" sizes="114x114" href="{{ asset_url() . 'apple-icon-114x114.png' }}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{ asset_url() . 'apple-icon-120x120.png' }}">
    <link rel="apple-touch-icon" sizes="144x144" href="{{ asset_url() . 'apple-icon-144x144.png' }}">
    <link rel="apple-touch-icon" sizes="152x152" href="{{ asset_url() . 'apple-icon-152x152.png' }}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset_url('apple-icon-180x180.png') }}">
    <link rel="icon" type="image/png" sizes="192x192" href="{{ asset_url() . 'android-icon-192x192.png' }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset_url() . 'favicon-32x32.png' }}">
    <link rel="icon" type="image/png" sizes="96x96" href="{{ asset_url() . 'favicon-96x96.png' }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset_url() . 'favicon-16x16.png' }}">
    <link rel="manifest" href="{{ asset_url() . 'manifest.json' }}">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="{{ asset_url() . 'ms-icon-144x144.png' }}">
    <meta name="theme-color" content="#ffffff">

    <!-- Styles -->
    <link href="{{ asset_url() . 'admin/css/flag-icon.min.css' }}" rel="stylesheet">
    <link href="{{ asset_url() . 'admin/css/simple-line-icons.css' }}" rel="stylesheet">
    <!-- Main styles for this application-->
    <link href="{{ asset_url() . ('admin/css/' . strtolower(config('app.name', 'addmee')) . '.css') }}"
        rel="stylesheet">
    <style type="text/css">
        .mt-6 {
            margin-top: 5rem !important;
        }

        .logo {
            opacity: 1;
            height: 160px;
            width: 160px;
            right: 50%;
            z-index: 1;
            position: absolute;
            bottom: -55px;
            ;
            transform: translate3d(50%, 0, 0);
            top: unset !important;
            /* background-size: 100%;
            background-repeat: no-repeat;
            background-position: bottom;
            width: 100px;
            vertical-align: middle;
            background-color: #fff;
            border-radius: 100%;*/
            /* border-color: #fff;
            border-width: 6px;
            border-style: solid;
            overflow: hidden; */
            /* left: 0; */
            /* transform: translate3d(50%, 0, 0);
            bottom: -50px;*/
            /* background-image: url({{ asset_url() . 'admin/img/profileImg.png' }}); */

        }

        .logo img {
            /* height: 100%;
            border-radius: 40px;
            border: 3px; */
            /* width: 100%;
            margin-right: 20px; */
            object-fit: scale-down;
            display: block;
            margin: 0 auto;
            width: 100%;
            height: 100%;
            border-radius: 100%;
            box-shadow: 6px 10px 25px 0 rgba(0, 0, 0, 0.19), 0 6px 20px 0 rgba(0, 0, 0, 0.19) !important;
            background-color: {{ isset($settings['photo_border_color']) ? $settings['photo_border_color'] : '#fff' }};
        }

        .logo .company-logo {
            width: 60px;
            height: 60px;
            margin: 0;
            position: absolute;
            bottom: 0;
            right: 50%;
            transform: translate3d(172%, 0, 0px);
            box-shadow: rgba(128, 128, 128, 0.25) 0px 4px 4.84px;
        }

        .profile-title {
            min-height: 42px;
            margin: 0;
            /* padding-left: 15px; */
            text-align: center;
        }

        .profile-image {
            position: relative;
        }

        .width-100 {
            width: 100%;
        }

        .user-img img {
            height: 120px;
        }

        .username {
            font-size: 18px !important;
            color: grey;
            text-align: center;
            width: 100%;
            padding-top: 20px;
            margin-bottom: 14px;
            font-weight: 400;
            font-style: normal;
            float: left;
        }

        .edit {
            padding: 7px;
            letter-spacing: 0.3px;
            font-size: 13px;
            line-height: 21px;
            color: #000000;
        }

        .edit:hover,
        .edit:visited {
            color: #2E2E2E;
        }

        .bio-text {
            text-align: center;
            /* margin-bottom: 30px; */
            width: 100%;
            float: left;
            padding: 0 15px;
            font-size: 17px;
            font-weight: 400;
            margin-top: 15px;
        }

        .bio {
            line-height: 21px;
            word-break: keep-all;
            text-align: left;
            margin: 0;
            color: {{ isset($settings['text_color']) ? $settings['text_color'] : '#616161' }};
        }

        .logo-tab {
            text-align: center;
            margin: 40px 0;
        }

        .wrp {
            text-align: center;
            padding-top: 1px;
            /* overflow: hidden; */
        }

        .user-img {
            background-color: #fff;
            height: 270px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-position: center;
            background-size: 100.5%;
            background-repeat: no-repeat;
        }

        .bg-row-- {
            background-image: url('{{ uploads_url() . 'img/bg.png' }}');
            background-size: 100%;
            margin-top: 44px;
        }

        .bg-row {
            background-color: {{ isset($settings['bg_color']) ? $settings['bg_color'] : '#f8f8f8' }};
            /* margin-top: 44px; */
        }

        .profile-name {
            color: {{ isset($settings['text_color']) ? $settings['text_color'] : '#080808' }};
            /* margin-bottom: 15px; */
            font-size: 20px;
            font-weight: 600;
            text-align: left;
            padding-left: 15px;
        }

        #name-web-view-a {
            text-align: left;
            font-size: 16px;
            float: left;
            padding-left: 15px;
            color: {{ isset($settings['text_color']) ? $settings['text_color'] : '#9E9E9E' }};
        }

        .user-designation {
            text-align: left;
            font-size: 18px;
            padding-left: 15px;
            color: {{ isset($settings['text_color']) ? $settings['text_color'] : '#616161' }};
            font-weight: 600;
        }

        .company-name {
            text-align: left;
            font-size: 16px;
            padding-left: 15px;
            color: {{ isset($settings['text_color']) ? $settings['text_color'] : '#9E9E9E' }};
        }

        .social-titles {
            float: left;
            color: {{ isset($settings['text_color']) ? $settings['text_color'] : '#2E2E2E' }};
            font-size: 14px;
            max-width: 100%;
            min-width: 100%;
        }

        .social-titles:hover {
            color: {{ isset($settings['text_color']) ? $settings['text_color'] : '#2E2E2E' }};
            text-decoration: underline;
        }

        .m-lr {
            margin-left: 2.8%;
            margin-right: 2.8%;
        }

        .m-l {
            margin-left: 7px;
        }

        .m-r {
            margin-right: 7px;
        }

        .powered-by {
            float: left;
            width: 100%;
            margin: 25px 0;
        }

        .powered-by a.shadow {
            padding: 10px 20px;
            background-color: #603E93;
            color: #fff;
            font-size: 16px;
        }

        .patent,
        .patent:hover {
            color: #000000;
            font-size: 16px;
            font-weight: bold;
        }

        .top-banner-app {
            letter-spacing: 0.7px;
            display: none;
        }

        .shadow {
            margin-bottom: 5px;
            border-radius: 17px !important;
        }

        .my-btn {
            margin: 0 auto;
            width: 85%;
            background-color: #603E93;
            color: white;
            font-size: 18px;
            font-weight: 700
        }

        .form-control {
            background-color: #fff;
        }

        @font-face {
            font-family: heiti-tc;
            src: url("{{ uploads_url() . 'img/STHeiti-Medium.ttc' }}");
        }

        @font-face {
            font-family: heiti-tc-light;
            src: url("{{ uploads_url() . 'img/STHeiti-Light.ttc' }}");
        }

        @import url('https://fonts.googleapis.com/css2?family=Inter&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap');

        body {
            font-family: 'Poppins', sans-serif;
            /*font-family:"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif*/
        }

        .blurOff {
            filter: blur(5.5px);
            -webkit-user-select: none;
            -webkit-touch-callout: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        .proxima-nova {
            margin-top: 20px;
            margin-bottom: 50px;
            margin-left: 40px;
            margin-right: 40px;
            font-size: 18px
        }

        .alert {
            padding: .25rem 0.25rem;
            border-radius: 0;
            font-size: 13px;
        }

        .brand-profiles,
        .my-profiles {
            /* background-color: {{ isset($settings['innser_section_bg_color']) ? $settings['innser_section_bg_color'] : '#fff' }}; */
            background-image: linear-gradient(#ffffff00 0.01%, #ffffff 10%, #ffffff 85%, #ffffff00 100%);
            /* margin: 15px; */
            border-radius: 5px;
            padding-bottom: 10px;
            float: left;
        }

        .user-details-block {
            /* background-color: #fff; */
            margin: 15px 0;
            border-radius: 5px;
            float: left;
            width: 100%;
        }

        .brand-profiles .grid-square-normal {
            width: 16%;
            padding: 0;
            margin-bottom: inherit;
        }

        .brand-profiles .grid-square-normal img {
            border-radius: 10px;
        }

        .no-padding {
            padding: 0;
        }

        .grid-square-normal {
            width: 25%;
            display: inline-block;
            padding: 0;
            margin: 15px 3%;
            margin-bottom: -10px;
            color: black;
            position: relative;
        }

        @media (max-width: 767px) {
            .hidden-xs {
                display: none;
            }
        }

        @media (max-width: 370px) {
            .top-banner-app {
                font-size: 11px;
            }
        }

        .top-banner-app:hover {
            color: #fff;
        }

        .red-button {
            display: block;
            background-color: {{ isset($settings['btn_color']) ? $settings['btn_color'] : '#000' }};
            /*#185698;*/
            letter-spacing: 0.3px;
            font-size: 14px;
            line-height: 21px;
            font-weight: 600;
            color: #fff;
            align-items: center;
            padding: 8px 15px;
            border: 1px solid {{ isset($settings['btn_color']) ? $settings['btn_color'] : '#000' }};
            border-radius: 7px;
            box-shadow: none !important;
            text-align: center;
        }

        .red-button:hover {
            background-color: {{ isset($settings['btn_color']) ? $settings['btn_color'] : '#000' }};
            border: 1px solid {{ isset($settings['btn_color']) ? $settings['btn_color'] : '#000' }};
        }

        @media (max-width: 370px) {
            .red-button {
                padding: 8px 8px;
            }
        }

        .focused-profile {
            width: calc(100% - 0px);
            margin: 15px 0;
            background-color: #f5f5f4;
            padding: 10px calc(3% + 10px);
        }

        .focused-profile .social-titles {
            display: flex;
            align-items: center;
        }

        .focused-profile .social-titles:hover {
            text-decoration: none !important;
        }

        .focused-profile img {
            max-width: 140px;
        }

        .focused-profile h6 {
            font-size: 1.25rem;
            font-weight: 500;
            line-height: 1.6;
            color: black;
            width: 100%;
            white-space: pre-wrap;
            overflow-wrap: break-word;
            word-break: break-word;
        }

        .focused-profile span {
            font-size: 12px;
            line-height: 1.57;
            color: black;
            width: 100%;
            white-space: pre-wrap;
            overflow-wrap: break-word;
            word-break: break-word;
            font-weight: normal;
        }
    </style>

    <!-- Scripts -->
    <script src="{{ asset_url() . 'admin/js/bootstrap.min.js' }}" defer></script>
    <script src="{{ asset_url() . 'admin/js/jquery.min.js' }}"></script>
</head>
@if (isset($settings['bg_image']) && $settings['bg_image'] != '')

    <body
        style="background-image: url('{{ $settings['bg_image'] }}'); background-repeat: no-repeat; background-size: cover;">
    @else

        <body>
@endif
<div class="container">
    <div class="row">
        <a href="https://addmee.de/" class="top-banner-app"><img src="{{ uploads_url() . 'img/cart.png' }}"
                width="28">&nbsp;Tippe hier, um jetzt deinen AddMee zu erhalten</a>
        <div class="col-md-3 col-xs-12 col-lg-3 hidden-xs">&nbsp;</div>
        @yield('content')
    </div>
</div>
<script type="module">
		// Import the functions you need from the SDKs you need
		import {
			initializeApp
		} from "https://www.gstatic.com/firebasejs/9.14.0/firebase-app.js";
		import {
			getAnalytics
		} from "https://www.gstatic.com/firebasejs/9.14.0/firebase-analytics.js";
		// TODO: Add SDKs for Firebase products that you want to use
		// https://firebase.google.com/docs/web/setup#available-libraries

		// Your web app's Firebase configuration
		// For Firebase JS SDK v7.20.0 and later, measurementId is optional
		const firebaseConfig = {
			apiKey: "AIzaSyCziXI5o4vw3-6E-c1Yf4EnyURbVZddIFM",
			authDomain: "addmee-f98d1.firebaseapp.com",
			projectId: "addmee-f98d1",
			storageBucket: "addmee-f98d1.appspot.com",
			messagingSenderId: "589918697888",
			appId: "1:589918697888:web:3db36f07d56f12fda10cc5",
			measurementId: "G-NY3L2DM1VR"
		};

		// Initialize Firebase
		const app = initializeApp(firebaseConfig);
		const analytics = getAnalytics(app);
	</script>
</body>

</html>
