@extends('errors::minimal')

@section('title', translate('Page Expired'))
@section('code', '419')
@section('message', translate('Page Expired'))
