<footer class="app-footer noprint">
    <div>
        <a href="javascript:;">{{ config('app.name', 'GetIn') }}</a>
        <span>© {{ date('Y') }}, All Rights Reserved.</span>
    </div>
    <div class="ml-auto">
        <span>Powered by</span>
        <a href="javascript:;">{{ config('app.name', 'GetIn') }}</a>
    </div>
</footer>