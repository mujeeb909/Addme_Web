@extends('layouts.front')

@section('content')
    @if ($blurOff == 'blurOn')
        <style type="text/css">
            .edit:hover,
            .edit:visited {
                color: #2E2E2E;
                text-decoration: underline;
            }
        </style>
    @else
        <style type="text/css">
            .opac-3 {
                opacity: 0.3
            }
        </style>
    @endif

    @php
        $save_contact['en'] = 'Save Contact';
        // $save_contact['en'] = 'Kontakt<br>speichern'; 
        $save_contact['de'] = 'Kontakt<br>speichern';
        $connect['en'] = 'Connect';
        $connect['de'] = 'Vernetzen';
        $private['en'] = 'This profile is private';
        $private['de'] = 'Dieses Profil ist privat';
        $your_name['en'] = 'Your name';
        $your_name['de'] = 'Dein Name';
        $your_email['en'] = 'Your email';
        $your_email['de'] = 'Deine E-Mail';
        $your_phone_number['en'] = 'Your phone number';
        $your_phone_number['de'] = 'Deine Telefonnummer';
        $your_note['en'] = 'Leave a note';
        $your_note['de'] = 'Eine Notiz hinterlassen';
        $your_connect['en'] = 'Connect';
        $your_connect['de'] = 'Vernetzen';
        $name_alert['en'] = 'Please enter your name.';
        $name_alert['de'] = 'Bitte Name eingeben.';
        $email_alert['en'] = 'Please enter your email.';
        $email_alert['de'] = 'Bitte E-Mail eingeben..';
        $phone_alert['en'] = 'Please enter your phone number.';
        $phone_alert['de'] = 'Bitte Telefonnummer eingeben.';
        $note_alert['en'] = 'Please enter a note.';
        $note_alert['de'] = 'Bitte Notiz eingeben.';
        $success_msg['en'] = 'Successfully added you to profile.';
        $success_msg['de'] = 'Sie wurden erfolgreich zum Profil hinzugefügt.';
    @endphp

    <div class="col-md-12 col-xs-12 col-lg-6 shadow-profile bg-row" id="content-section">
        <div class="profile {{ $blurOff }}">
            @php
                $has_subscription = chk_subscription($profile);
                if ($has_subscription['success'] == false) {
                    /* $profile->logo = ''; */
                }
            @endphp

            <div id="profile-image" class="profile-image">
                <!--<img alt="Pro" class="shadow" style="position: absolute; width: 32px; height: 32px; top: 15px; left: 15px" src="Probutton.png">-->
                <div class="user-img" style="background-image:url(<?php echo $profile->banner != '' && file_exists(icon_dir() . $profile->banner) ? image_url($profile->banner) : uploads_url() . 'img/customer.png'; ?>)">
                    <!--<img alt="profile picture" src="">-->
                </div>
                <input type="file" name="file" style="display: none" id="photo">

                <div class="logo">
                    <img
                        src="{{ $profile->logo != '' && file_exists(icon_dir() . $profile->logo) ? image_url($profile->logo) : uploads_url() . 'img/dp_profile.png' }}">
                </div>
            </div>

            <div class="col-12 pull-left mt-3">
                <div class="user-details-block">
                    <div class="flex-row username">
                        <div class="flex-row">
                            <div class="col-12 col-8-- pull-left no-padding">
                                <h3 class="profile-name">
                                    {{ $profile->first_name == '' && $profile->last_name == '' ? $profile->name : $profile->first_name . ' ' . $profile->last_name }}
                                </h3>
                                @if ($profile->designation != '')
                                    <h3 class="user-designation">{{ $profile->designation }}</h3>
                                @endif
                                @if ($profile->company_name != '')
                                    <h3 class="company-name"><img alt="profile picture" width="16"
                                            src="{{ uploads_url() . 'img/company-icon.png' }}"> {{ $profile->company_name }}
                                    </h3>
                                @endif
                                @if ($profile->company_address != '')
                                    <h3 class="company-name"><img alt="profile picture" width="16"
                                            src="{{ uploads_url() . 'img/address.png' }}"> {{ $profile->company_address }}
                                    </h3>
                                @endif
                            </div>
                            <div class="col-2 pull-left no-padding d-none">
                                @if ($ContactCard > 0)
                                    <a
                                        href="{{ $blurOff == 'blurOn' ? main_url() . '/contact-card/' . encrypt($profile->id) : '#' }}">
                                        <img alt="profile picture" src="{{ uploads_url() . 'img/contact-card.png' }}"
                                            style="width: 50px; max-width: 90%; float:right; top: -10px; position: relative;"></a>
                                @endif
                            </div>
                            <div class="col-2 pull-left no-padding d-none">
                                <a id="edit" data-toggle="modal" data-target="#myModal" href="javascript:;">
                                    <img alt="profile picture" src="{{ uploads_url() . 'img/connect-icon.png' }}"
                                        style="width: 50px; max-width: 90%; top: -10px; position: relative;"></a>
                            </div>
                            <div class="col-12 pull-left no-padding">
                                <a id="name-web-view-a"><img alt="profile picture" width="16"
                                        src="{{ uploads_url() . 'img/link-icon.png' }}">
                                    {{ main_url_wo_http() . $profile->username }}</a>
                                @if ($profile->bio != '')
                                    <div class="bio-text">
                                        <p id="bio_change" class="bio">{!! nl2br($profile->bio) !!}</p>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                <div class="user-details-block" style="background-color: transparent">
                    <div class="d-flex flex-row bd-highlight justify-content-center opac-3" id="button-div">
                        <div class="col-6 d-none">
                            <a href="javascript:;" data-toggle="modal" data-target="#myModal"
                                class="btn btn-primary red-button connect-btn"><img width="20" class="pull-left"
                                    src="{{ uploads_url() . 'img/ic_connect.png' }}"><span
                                    style="display: inline-block;text-align: center;">{{ $connect[$language] }}</span></a>
                        </div>
                        <div class="col-6 d-none">
                            @if ($ContactCard > 0)
                                <a href="{{ $blurOff == 'blurOn' ? main_url() . '/contact-card/' . encrypt($profile->id) : '#' }}"
                                    class="btn btn-primary red-button save-contact"><img width="20" class="pull-left"
                                        src="{{ uploads_url() . 'img/ic_contact_card.png' }}"><span
                                        style="display: inline-block;text-align: center;">{!! $save_contact[$language] !!}</span></a>
                            @endif
                        </div>
                    </div>
                </div>
                <p id="username" hidden>
                    {{ main_url_wo_http() . $profile->username }}
                </p>
            </div>
            <div class="d-flex-- flex-row-- bd-highlight-- justify-content-center-- opac-3-- d-none">
                <!--<a id="add-to" class="btn btn-primary add-btn edit m-r" href="javascript:;"><b>Kontakt hinzufÃÂ¼gen</b></a> -->
                <a id="edit" data-toggle="modal" data-target="#myModal" class="btn btn-primary add-btn edit m-l"
                    href="javascript:;"><b>Connecten</b></a>
            </div>

            @if ($profile->is_public == 2)
                {{-- is_public --}}
            @elseif ($profile->is_public == 0 && $profile->profile_view == 'personal')
                {{-- is_public --}}
            @elseif (!empty($BusinessInfo) && $BusinessInfo->is_public == 2 && $profile->profile_view == 'business')
            @else
                @if (count($brand_profiles) > 0)
                    <div class="my-profiles brand-profiles">
                        <div class="flex-row wrp">
                            <h2
                                style="font-size: 20px;margin: 15px 0 5px 0;font-weight: 600;letter-spacing: 0.5px; text-align: left; padding-left: 15px;">
                                @if (!empty($brand) && 1 != 1)
                                    <img src="{{ $brand->logo != '' ? image_url($brand->logo) : uploads_url() . 'img/company-logo.png' }}"
                                        width="32">
                                @endif
                                {{ $brand_name }}
                            </h2>
                            @foreach ($brand_profiles as $t => $row)
                                <div class="grid-square-normal" data-link-id="31">
                                    <a id="{{ $row->title_de }}" rel="" target="_blank"
                                        href="{{ $row->profile_link }}" class="social-titles">
                                        <img class="shadow width-100" alt="{{ $row->title_de }}"
                                            src="{{ $row->icon }}">
                                        {{ $row->title_de }}
                                    </a>
                                </div>
                                @if ($t == 3)
                                    @php break; @endphp
                                @endif
                            @endforeach
                        </div>
                    </div>
                @endif
                <div class="my-profiles">
                    <div class="flex-row wrp">
                        @if (count($profiles) > 0)
                            @foreach ($profiles as $row)
                                <div class="grid-square-normal" data-link-id="31">
                                    @if ($row->profile_link == 'popup-link')
                                        <a id="{{ $row->title_de }}" href="javascript:;"
                                            class="social-titles popup-link">
                                            <img class="shadow width-100" alt="{!! $row->title_de !!}"
                                                src="{{ $row->icon }}">
                                            <p class="profile-title">{{ $row->title_de }}</p>
                                        </a>
                                    @else
                                        <a id="{{ $row->title_de }}" rel="" target="_blank"
                                            href="{{ $row->profile_link }}" class="social-titles">
                                            <img class="shadow width-100" alt="{!! $row->title_de !!}"
                                                src="{{ $row->icon }}">
                                            <p class="profile-title">{{ $row->title_de }}</p>
                                        </a>
                                    @endif
                                </div>
                            @endforeach
                        @endif
                    </div>
                </div>
            @endif
        </div>
        @if ($profile->is_public == 2)
            <div style="text-align: center; margin-top: 50px">
                <img alt="profile picture" width="40" src="{{ uploads_url() . 'img/padlock.png' }}">
                <p class="proxima-nova">{{ $private[$language] }}</p>
            </div>
        @elseif ($profile->is_public == 0 && $profile->profile_view == 'personal')
            <div style="text-align: center; margin-top: 50px">
                <img alt="profile picture" width="40" src="{{ uploads_url() . 'img/padlock.png' }}">
                <p class="proxima-nova">{{ $private[$language] }}</p>
            </div>
        @elseif (!empty($BusinessInfo) && $BusinessInfo->is_public == 2 && $profile->profile_view == 'business')
            <div style="text-align: center; margin-top: 50px">
                <img alt="profile picture" width="40" src="{{ uploads_url() . 'img/padlock.png' }}">
                <p class="proxima-nova">{{ $private[$language] }}</p>
            </div>
        @endif
        <div class="logo-tab">
            <div class="powered-by d-none">
                <strong> <a target="_blank" href="https://addmee.de/pages/app" class="shadow">Eigenes Profil
                        anlegen</a></strong>
            </div>
            <a href="javascript:;">
                <img alt='{{ config('app.name', '') }}' class="addmee-logo" height="40"
                    src="{{ uploads_url() . 'img/addmee-logo.png' }}">
            </a>
            <div class="powered-by">
                <!-- <a class="patent" href="#">Patentiert <img alt='{{ config('app.name', '') }}' height="13" src="{{ uploads_url() . 'img/checked.png' }}"></a> -->
            </div>
        </div>
        @if ($blurOff == 'blurOn')
            <div class="modal fade" id="myModal" role="dialog" style="display: none;" aria-hidden="true">
                <div class="modal-dialog modal-md" style="top: 12vh; width: 85%; margin: 0 auto;">
                    <div class="modal-content" style="text-align: center; border-radius: 15px">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">ÃÂ</button>
                            <h4 class="modal-title"
                                style="text-align: center; margin: 0 auto; font-weight: 700; width: 80%">
                                @if ($language == 'de')
                                    Mit
                                    {{ $profile->first_name == '' && $profile->last_name == '' ? $profile->name : $profile->first_name . ' ' . $profile->last_name }}
                                    verbinden
                                @else
                                    Connect with
                                    {{ $profile->first_name == '' && $profile->last_name == '' ? $profile->name : $profile->first_name . ' ' . $profile->last_name }}
                                @endif
                            </h4>
                        </div>
                        {{-- <p class="mt-2">Teile deine Informationen mit
                            {{ $profile->first_name == '' && $profile->last_name == '' ? $profile->name : $profile->first_name . ' ' . $profile->last_name }}
                        </p> --}}
                        <div class="modal-body">
                            <input type="text" autocomplete="name" id="name" value=""
                                class="form-control mb-3" placeholder="{{ $your_name[$language] }}">
                            <p class="mb-3 text-left" id="name_info"></p>
                            <input type="email" autocomplete="email" id="email" value=""
                                class="form-control mb-3 " placeholder="{{ $your_email[$language] }}">
                            <p class="mb-3 text-left" id="email_info"></p>
                            <input type="tel" autocomplete="tel" id="number" value=""
                                class="form-control mb-3" placeholder="{{ $your_phone_number[$language] }}">
                            <input type="hidden" id="user_id" value="{{ $profile->id }}">
                            <p class="mb-3 text-left" id="number_info"></p>
                            <textarea id="note" value="" class="form-control mb-3" placeholder="{{ $your_note[$language] }}"
                                rows="2"></textarea>
                            <p class="mb-3 text-left" id="note_info"></p>
                            <div style="display: none">
                                <input type="checkbox" class="checkboxcontact" id="checkboxcontact"
                                    style="transform: scale(1.3); margin-right: 5px; margin-top: 10px;"
                                    name="bIsStatPrivate">
                                <label for="checkboxcontact" style="font-weight: 600; font-size: 15px">Email me Hello's
                                    profile</label>
                            </div>
                        </div>
                        <div class="modal-footer" style="border: 0px">
                            <button type="button" onClick="addPerson()"
                                class="btn btn-default my-btn">{{ $your_connect[$language] }}</button>
                        </div>
                        <div class="modal-body">
                            <p class="mb-3 text-center" id="msg_info"></p>
                        </div>
                    </div>
                </div>
            </div>
        @endif
        <script type="text/javascript">
            var relative_path = '';
            var site_url = '';
            var xhr;

            function addPerson() {

                var name = $.trim($('#name').val());
                var email = $.trim($('#email').val());
                var number = $.trim($('#number').val());
                var note = $.trim($('#note').val());
                var user_id = $.trim($('#user_id').val());
                if (name == '') {
                    $('#name_info').html('<span class="alert alert-danger">{{ $name_alert[$language] }}</span>').fadeIn(150)
                        .delay(5000).fadeOut(150);
                    return false;
                }

                if (email == '') {
                    $('#email_info').html('<span class="alert alert-danger">{{ $email_alert[$language] }}</span>').fadeIn(150)
                        .delay(5000).fadeOut(150);
                    return false;
                }

                if (number == '') {
                    $('#number_info').html('<span class="alert alert-danger">{{ $phone_alert[$language] }}</span>').fadeIn(150)
                        .delay(5000).fadeOut(150);
                    return false;
                }

                if (note == '') {
                    $('#note_info').html('<span class="alert alert-danger">{{ $note_alert[$language] }}</span>').fadeIn(150)
                        .delay(5000).fadeOut(150);
                    return false;
                }

                number = number.replace('+', '%2B')
                var data = 'name=' + name + '&email=' + email + '&phone_no=' + number + '&note=' + note +
                    '&user_id=' +
                    user_id + '&_token={{ csrf_token() }}';
                $('#msg_info').html('<span class="alert alert-success">Processing...</span>').fadeIn(150);
                $.ajax({
                    type: "POST",
                    url: '{{ main_url() }}/api/user_note',
                    dataType: "json",
                    data: data,
                    success: function(response) {
                        console.log(response);
                        if (response.success) {
                            $('#msg_info').html(
                                    '<span class="alert alert-success">{{ $success_msg[$language] }}</span>')
                                .fadeIn(150).delay(5000).fadeOut(150);
                            //$('button.close').click();
                            $('#name').val('');
                            $('#email').val('');
                            $('#number').val('');
                            $('#note').val('');
                        } else {
                            $('#msg_info').html('<span class="alert alert-danger">Error.</span>').fadeIn(
                                150).delay(5000).fadeOut(150);
                        }
                        //location.reload();
                        //$('#tr_'+de_utoa(id)+'').remove();
                    },
                    error: function() {
                        alert("Sorry, The requested property could not be found.");
                    }
                });
            }

            function reset_offset(val) {
                offset = 0;
                $('#load-more').fadeOut(150);
            }

            function utoa(str) {
                return window.btoa(window.btoa(window.btoa(window.btoa(window.btoa(window.btoa(window.btoa(unescape(
                    encodeURIComponent(str)))))))));
            }

            $(document).ready(function(e) {
                var w = $('#content-section').width()
                var r = (parseInt(16) / parseInt(9))
                var h = (parseFloat(w) / parseFloat(r))

                $('.user-img').css('height', h + 'px');

                getLocation();
            });

            function error() {}

            function getLocation() {
                return;
                if (navigator.geolocation) {
                    var options = {
                        enableHighAccuracy: true,
                        timeout: 5000,
                        maximumAge: 0
                    };
                    navigator.geolocation.getCurrentPosition(showPosition, error, options);
                } else {
                    x.innerHTML = "Geolocation is not supported by this browser.";
                }
            }

            function showPosition(position) {
                return;
                //console.log(position.coords.latitude, position.coords.longitude);
                var data = 'user_id={{ $profile->id }}&latitude=' + position.coords.latitude + '&longitude=' + position.coords
                    .longitude;
                $.ajax({
                    type: "GET",
                    url: '{{ main_url() }}/api/tap_view/',
                    dataType: 'json',
                    data: data,
                    success: function(response) {

                        console.log(position);
                    }
                });
            }

            $(document).ready(function() {
                $('#button-div .col-6').removeClass('d-none', {
                    duration: 500
                })

                $('.popup-link').on('click', function() {
                    $('.popup-section').css({
                        display: 'block',
                        width: 400 + 'px'
                    });
                });

                $('.close-btn').on('click', function() {
                    $('#success').fadeOut(100)
                    $('.icon-img').fadeOut(200)
                });
            })

            let language = 'en'
            if (window.navigator.language) {
                language = window.navigator.language.substr(0, 2) 
                 if (language != 'en' && language != 'de') {
                    language = 'en'
                }
            }

            if (language != 'en' && language != '<?php echo $language; ?>') {
                $.ajax({
                    type: "POST",
                    url: '{{ main_url() }}/api/update_browser_language',
                    dataType: "json",
                    data: 'language=' + language,
                    success: function(response) {
                        location.reload();
                        //$('#tr_'+de_utoa(id)+'').remove();
                    },
                    error: function() {
                        // alert("Sorry, The requested property could not be found.");
                    }
                });
            }
            console.log('a', language, '<?php echo $language; ?>')
            if (language == 'de') {
                $(document).ready(function() {
                    $('.red-button').css('display', 'flex');
                    var height = $('#button-div .save-contact').height();
                    console.log(height)
                    height = height + parseInt(16)
                    $('#button-div .connect-btn').css('height', height + 'px');
                    $('#button-div .connect-btn span, #button-div .save-contact span').css('margin-left', '10px');
                    $('#button-div .connect-btn span, #button-div .save-contact span').css('width', '100%'); 
                });
            }
        </script>

        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC4sckpx0c1d9JOug9jJg_URJI_wgVSFVw"></script>

        {{-- popup --}}
        <style>
            .popup-section {
                position: fixed;
                z-index: 999;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                min-height: 300px;
                width: 400px;
                background-color: #fff;
                margin: 40px auto;
                box-shadow: 10px 10px 28px 1px rgba(0, 0, 0, 0.75);
                border-radius: 15px;
                display: none;
                max-width: 90%;
                padding: 20px;
            }

            .text-center {
                text-align: center
            }

            .popup-section h1 {
                font-style: normal;
                font-weight: 600;
                font-size: 20px;
                line-height: 29px;
                text-align: center;
                color: #080808;
            }

            .popup-section .btn {
                max-width: 80%;
                font-style: normal;
                font-weight: 700;
                font-size: 15px;
                line-height: 18px;
                display: flex;
                justify-content: center;
                text-align: center;
                border-radius: 17px !important;
                padding: 10px 50px !important;
                margin: 5px auto;
            }

            .popup-section .success-btn {
                color: #185698;
                border: 2px solid #185698 !important;
            }

            .popup-section .success-btn:hover {
                color: #fff;
                background-color: #185698 !important;
            }
        </style>
        <section class="popup-section" id="success">
            <div class="icon">
                <h1 class="alert-heading">Scan QR to Connect to WiFi</h1>
            </div>
            <div class="popup-content text-center">
                <img src="{{ uploads_url() . 'qrcodes/' . $profile->id . '.svg' }}"
                    style="max-width: 70%;margin: 15px 0;" alt="">
            </div>
            <div class="popup-btns mb-4">
                <a class="btn border-theme success-btn close-btn" href="javascript:;">Close</a>
            </div>
        </section>
    @endsection
