<?php

include __DIR__ . '/vendor/autoload.php';

use Sanchescom\WiFi\WiFi as WiFiConnect;

class WiFi
{
    public $device;

    /**
     * @throws Exception
     */
    public function getAllNetworks()
    {
        $networks = WiFiConnect::scan()->getAll();
        echo '<pre>';
        print_r(json_decode(json_encode($networks)));
        // foreach ($networks as $network) {
        //     echo $network . "\n" . PHP_EOL;
        // }
    }

    /**
     * @param $ssid
     * @param $password
     */
    public function connect($ssid, $password)
    {
        try {
            WiFiConnect::scan()->getBySsid($ssid)->connect($password, $this->device);
        } catch (Exception $exception) {
            echo $exception->getMessage();
        }
    }

    /**
     * @throws Exception
     */
    public function disconnect()
    {
        $networks = WiFiConnect::scan()->getConnected();

        foreach ($networks as $network) {
            $network->disconnect($this->device);
        }
    }
}

// $WiFi = new WiFi();
// try {
//     // $WiFi->device = 'en1';
//     // $WiFi->getAllNetworks();
//     $WiFi->connect('HUAWEI-nKuj', 'Rt2Bxccz');
//     // $example->disconnect();
// } catch (Exception $e) {
//     //
// }
